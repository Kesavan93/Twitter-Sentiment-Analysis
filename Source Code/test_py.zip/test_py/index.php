<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Lang" content="en">

<link rel="stylesheet" href="css/query.css">

<title>Twitter Sentiment Analysis</title>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>





</head>
<body>



	<div class="single category">
		<h3 class="side-title">Twitter Sentiment Analysis</h3>

<form method="GET">
		<ul class="list-unstyled">
			<li style="list-style-type: none;"><b>Keyword &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;<input type="text" name="q" required /> </b><span class="pull-right"></span></li>
			<li style="list-style-type: none;"><b>Tweets Qty &nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;<input type="text" name="qty" required /> </b><span class="pull-right"></span></li>
			<li style="list-style-type: none;"><input class="button" type="submit" value="SEARCH" onclick="drawChart();"/><span class="pull-right"></span></li>
		</ul>   
</form>


   </div>



<?php

if(isset($_GET['q']) && $_GET['q']!='') {
    include_once(dirname(__FILE__).'/config.php');
    include_once(dirname(__FILE__).'/lib/TwitterSentimentAnalysis.php');

    $TwitterSentimentAnalysis = new TwitterSentimentAnalysis(DATUMBOX_API_KEY,TWITTER_CONSUMER_KEY,TWITTER_CONSUMER_SECRET,TWITTER_ACCESS_KEY,TWITTER_ACCESS_SECRET);

    //Search Tweets parameters as described at https://dev.twitter.com/docs/api/1.1/get/search/tweets
    $twitterSearchParams=array(
        'q'=>$_GET['q'],
        'lang'=>'en',
        'count'=>$_GET['qty'],
    );
    $results=$TwitterSentimentAnalysis->sentimentAnalysis($twitterSearchParams);


    ?>
<div class="container">
	<div class="row">
		
        
        <div class="col-md-12">
        <h4>Results for "<?php echo $_GET['q']; ?>"</h4>
        <div class="table-responsive">
		
              <table id="mytable" class="table table-bordred table-striped">
                   
                <thead>
                   
                   <th>ID</th>
                    <th>USER</th>
                     <th>TEXT</th>
                     <th>TWITTER LINK</th>
                     <th>SENTIMENT</th>
				</thead>

        <?php
		$pos = 0;
		$neg = 0;
		$neu = 0;
		$count = 0;
        foreach($results as $tweet) {
            $count = $count + 1;
			
            $color=NULL;
            if($tweet['sentiment']=='positive') {
                $color='#00FF00';
				$pos = $pos + 1;
            }
            else if($tweet['sentiment']=='negative') {
                $color='#FF0000';
				$neg = $neg + 1;
            }
            else if($tweet['sentiment']=='neutral') {
                $color='#FFFFFF';
				$neu = $neu + 1;
            }
            ?>
			<tbody>
            <tr style="background:<?php echo $color; ?>;">
                <td><?php echo $tweet['id']; ?></td>
                <td><?php echo $tweet['user']; ?></td>
                <td><?php echo $tweet['text']; ?></td>
                <td><a href="<?php echo $tweet['url']; ?>" target="_blank">View</a></td>
                <td><?php echo $tweet['sentiment']; ?></td>
            </tr>
			</tbody>
            <?php
        }
		
		$prob_pos = ($pos/$count)*100;
		$prob_neg = ($neg/$count)*100;
		$prob_neu = ($neu/$count)*100;
		
        ?>    
    </table>

	
            </div>
            
        </div>
	</div>
</div>
    <?php
}

?>

<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);

// Draw the chart and set the chart values
function drawChart() {
  var data = google.visualization.arrayToDataTable([
  ['Opinion', 'Overall Tweets'],
  ['Positive Review', <?php echo $prob_pos; ?> ],
  ['Negative Review', <?php echo $prob_neg; ?> ],
  ['Neutral Review', <?php echo $prob_neu; ?> ]
]);

  // Optional; add a title and set the width and height of the chart
  var options = {'title':'Opinion Percentage :', 'width':550, 'height':400};

  // Display the chart inside the <div> element with id="piechart"
  var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  chart.draw(data, options);
}
</script>

<div id="piechart" style="position: absolute; left: 25%; border: 2px solid black;"></div> 

  
</body>
</html>
