<?php

// Configure your Datumbox API Key. Get yours at http://www.datumbox.com/apikeys/view/
define('DATUMBOX_API_KEY', 'b31e8f978640a8852de3c365c299f913');

// Configure your OAuth settings from your application at https://dev.twitter.com/apps

define('TWITTER_CONSUMER_KEY', '5YeejO2mjW5OCi8PGU90Ug1Yv');
define('TWITTER_CONSUMER_SECRET', 'IeIV03egRWq87esqBxAVec36zpUOb3N1XbEeVithMm22tje7D3');


// Configure authentication credentials.
// you can generate your own access key from the link above

define('TWITTER_ACCESS_KEY', '988613367928569856-QbzlZUzylGrUO6BMaJBZL0W7l4IyBzF');
define('TWITTER_ACCESS_SECRET', '3CefknQYUEe1O0bZHKK6wKwMZYQoLkctTpA1E3mkgWOAo'); 